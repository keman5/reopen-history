# Reopen History 1.0.0: reviewer source

Read docs/REVIEW-BUILD.md for exact reproduction commands and third-party provenance.
The extension source is in extension/. The third-party/ directory contains the exact installed tldts and tldts-core packages, including readable sources, licenses and source maps. These are reference copies, not executable build dependencies.
